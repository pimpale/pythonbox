from time import sleep

print("YEAAAAA")
sleep(3)
print("WOOOOOOOO")
exit(123)
